# MYRail — Malaysia Train Journey & Booking Integration Starter

MYRail is a browser-friendly frontend + Node.js/Express backend + Supabase/PostgreSQL schema scaffold for a Malaysian rail journey app.

## Important operational status
This project is **not an authorized KTMB ticket seller** and does not issue gate-valid tickets. KTMB's published terms state online ticket services are for personal use and restrict copying/adapting service information without prior written consent; KTMB also warns that tickets from unauthorized portals/apps may not be accepted. Before real ticket sales, obtain written authorization and an approved booking/ticket-validation integration from KTMB. Official information:
- https://www.ktmb.com.my/
- https://online.ktmb.com.my/
- https://www.ktmb.com.my/eticketpolicies.html

This scaffold deliberately:
- labels sample journeys as **DEMO / NOT LIVE**
- does not accept payments
- does not generate a purported official ticket or gate QR
- routes users to the official KTMB ticketing site for actual purchases
- separates a future provider adapter from demo search data

Do not deploy as a live ticket-selling service until the operator authorization, data rights, payment, privacy, consumer-protection, security and Google Play requirements are resolved.

## Requirements
- Node.js 20+ on a hosted Node service
- Supabase project (Postgres) if using database features
- Modern browser; frontend also works locally without Linux

## Run locally
1. `cd backend`
2. Copy `.env.example` to `.env` and fill `PORT` and optional Supabase settings.
3. `npm install`
4. `npm run dev`
5. Open `http://localhost:3000`

The Express server serves the frontend from `../frontend`.

## Deploy
Deploy the `backend` folder to a Node.js hosting provider. Configure environment variables there. Do not put service-role keys or payment secrets in frontend code.

## Future authorized integration
Implement `src/providers/railwayProvider.js` only after KTMB provides written permission, credentials, API docs, and ticket-validation rules. Provider must return verified journeys, fares, availability and genuine ticket references from the authorized system. Never treat locally generated IDs/QRs as tickets.

## Supabase
Run `database/schema.sql` in the Supabase SQL editor. The current demo app does not require Supabase to search sample journeys. Supabase configuration is reserved for future authenticated features.
