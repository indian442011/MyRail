const OFFICIAL_TICKETING = "https://online.ktmb.com.my/";
const fallbackStations = [
  "Arau","Alor Setar","Anak Bukit","Gurun","Sungai Petani","Tasek Gelugor","Butterworth",
  "Parit Buntar","Bagan Serai","Kamunting","Taiping","Kuala Kangsar","Ipoh","Batu Gajah",
  "Kampar","Tapah Road","Tanjung Malim","Rawang","Sungai Buloh","Kepong Sentral",
  "KL Sentral","Kuala Lumpur","Bank Negara","Mid Valley","Kajang","Seremban","Gemas",
  "Kluang","Segamat","JB Sentral","Tumpat","Wakaf Bharu","Kota Bharu (Wakaf Bharu)",
  "Kuala Lipis","Jerantut","Mentakab","Kuantan (route availability must be verified)"
];
// These are explicitly a starter list, not a complete official station catalogue.
// Do not advertise it as exhaustive. Confirm current names/routes with KTMB.
const demoJourneys = [
  {service:"ETS (sample)",from:"KL Sentral",to:"Ipoh",duration:"Approx. 2h 30m",note:"Illustrative route only"},
  {service:"ETS (sample)",from:"KL Sentral",to:"Butterworth",duration:"Approx. 4h",note:"Illustrative route only"},
  {service:"Komuter (sample)",from:"KL Sentral",to:"Kuala Lumpur",duration:"Short trip",note:"Illustrative route only"},
  {service:"Intercity (sample)",from:"Gemas",to:"Kluang",duration:"Route dependent",note:"Illustrative route only"}
];
const $ = id => document.getElementById(id);
function populateStations(){
  const unique = [...new Set(fallbackStations)].sort((a,b)=>a.localeCompare(b));
  for(const id of ["origin","destination"]){
    const select = $(id);
    select.innerHTML = "";
    unique.forEach(name=>{const o=document.createElement("option");o.value=name;o.textContent=name;select.appendChild(o);});
  }
  $("origin").value="KL Sentral";
  $("destination").value="Ipoh";
}
function localDateString(date){const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,"0"),d=String(date.getDate()).padStart(2,"0");return `${y}-${m}-${d}`;}
function initDate(){const input=$("travel-date");input.min=localDateString(new Date());input.value=input.min;}
$("swap").addEventListener("click",()=>{const a=$("origin"),b=$("destination"),v=a.value;a.value=b.value;b.value=v;});
$("search-form").addEventListener("submit",async event=>{
  event.preventDefault();
  const from=$("origin").value,to=$("destination").value,date=$("travel-date").value,pax=$("passengers").value;
  const box=$("results");
  if(from===to){box.innerHTML='<div class="notice">Please choose two different stations.</div>';return;}
  box.innerHTML='<div class="result-card"><div class="result-main"><div class="train-badge">↻</div><div><h3>Searching journey options…</h3><p>Checking the MYRail demo catalogue.</p></div></div></div>';
  try{
    const response=await fetch(`/api/journeys?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${encodeURIComponent(date)}&passengers=${encodeURIComponent(pax)}`);
    const data=await response.json();
    renderResults(data.journeys||[],from,to,date,pax);
  }catch(e){
    renderResults(demoJourneys.filter(j=>(j.from===from&&j.to===to)||(j.from===to&&j.to===from)),from,to,date,pax);
  }
});
function renderResults(journeys,from,to,date,pax){
  const box=$("results");
  if(!journeys.length){
    box.innerHTML=`<div class="result-card"><div class="result-main"><div class="train-badge">i</div><div><h3>No demo journey listed</h3><p>MYRail has no sample entry for ${escapeHtml(from)} → ${escapeHtml(to)}. This does not mean the real service is unavailable.</p></div></div><div class="result-meta"><a href="${OFFICIAL_TICKETING}" target="_blank" rel="noopener">Check official tickets ↗</a></div></div>`;
    return;
  }
  box.innerHTML=journeys.map(j=>`<article class="result-card"><div class="result-main"><div class="train-badge">🚆</div><div><h3>${escapeHtml(j.service||"Demo service")}</h3><p>${escapeHtml(from)} → ${escapeHtml(to)} · ${escapeHtml(date)} · ${pax} passenger(s)</p><p>${escapeHtml(j.note||"Demo data")} · ${escapeHtml(j.duration||"Time not verified")}</p></div></div><div class="result-meta"><span class="demo-tag">DEMO ONLY</span><strong>Not a live fare</strong><a href="${OFFICIAL_TICKETING}" target="_blank" rel="noopener">Book through KTMB ↗</a></div></article>`).join("");
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("year").textContent=new Date().getFullYear();
populateStations();initDate();
