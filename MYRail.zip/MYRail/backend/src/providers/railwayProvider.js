/**
 * Future adapter interface for an authorized railway provider.
 *
 * Do not scrape KITS, reverse engineer private endpoints, or invent API URLs.
 * Implement only after KTMB/operator provides written authorization, official docs,
 * credentials, commercial terms, and validation/ticket issuance rules.
 */
class RailwayProvider {
  async searchJourneys(_query) {
    throw new Error("Not configured: authorized railway provider required");
  }

  async createBooking(_journeySelection, _passengers) {
    throw new Error("Not configured: authorized railway provider required");
  }

  async getTicket(_providerBookingReference) {
    throw new Error("Not configured: authorized railway provider required");
  }

  async cancelBooking(_providerBookingReference) {
    throw new Error("Not configured: authorized railway provider required");
  }
}

module.exports = { RailwayProvider };
