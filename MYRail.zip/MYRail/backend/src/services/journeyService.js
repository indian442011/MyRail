const demo = require("../data/demoJourneys");

function searchDemoJourneys(from, to) {
  const norm = value => value.toLocaleLowerCase("en-MY").trim();
  return demo.filter(j =>
    (norm(j.from) === norm(from) && norm(j.to) === norm(to)) ||
    (norm(j.from) === norm(to) && norm(j.to) === norm(from))
  ).map(j => ({ ...j, dataStatus: "DEMO_NOT_LIVE" }));
}

module.exports = { searchDemoJourneys };
