// Illustrative examples only. Not official timetable data, live fares or bookable inventory.
module.exports = [
  { service: "ETS (sample)", from: "KL Sentral", to: "Ipoh", duration: "Approx. 2h 30m", note: "Illustrative route only" },
  { service: "ETS (sample)", from: "KL Sentral", to: "Butterworth", duration: "Approx. 4h", note: "Illustrative route only" },
  { service: "Komuter (sample)", from: "KL Sentral", to: "Kuala Lumpur", duration: "Short trip", note: "Illustrative route only" },
  { service: "Intercity (sample)", from: "Gemas", to: "Kluang", duration: "Route dependent", note: "Illustrative route only" }
];
