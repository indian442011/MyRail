require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const path = require("path");
const { searchDemoJourneys } = require("./src/services/journeyService");

const app = express();
const port = Number(process.env.PORT || 3000);
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));

const frontendDir = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendDir));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "MYRail", mode: "demo", liveTicketing: false, paymentsEnabled: false });
});

app.get("/api/stations", (_req, res) => {
  res.json({
    source: "starter-demo-list",
    exhaustive: false,
    live: false,
    stations: require("./src/data/stations")
  });
});

app.get("/api/journeys", (req, res) => {
  const { from, to, date, passengers = "1" } = req.query;
  if (typeof from !== "string" || typeof to !== "string" || !from.trim() || !to.trim()) {
    return res.status(400).json({ error: "from and to station names are required" });
  }
  if (from.trim().toLowerCase() === to.trim().toLowerCase()) {
    return res.status(400).json({ error: "Origin and destination must differ" });
  }
  if (date && (typeof date !== "string" || !/^\\d{4}-\\d{2}-\\d{2}$/.test(date))) {
    return res.status(400).json({ error: "date must use YYYY-MM-DD format" });
  }
  const pax = Number(passengers);
  if (!Number.isInteger(pax) || pax < 1 || pax > 6) {
    return res.status(400).json({ error: "passengers must be an integer between 1 and 6" });
  }
  res.json({
    mode: "demo",
    live: false,
    ticketingEnabled: false,
    paymentsEnabled: false,
    message: "Demo journeys are illustrative only. Use KTMB's official channel for actual availability, fares and valid tickets.",
    journeys: searchDemoJourneys(from.trim(), to.trim())
  });
});

app.post("/api/bookings", (_req, res) => {
  // Intentionally disabled until operator authorization and real provider integration.
  res.status(501).json({
    error: "Direct booking is not enabled.",
    code: "RAILWAY_AUTHORIZATION_REQUIRED",
    message: "MYRail cannot create genuine KTMB reservations or gate-valid tickets until an authorized booking integration is provided."
  });
});

app.post("/api/payments/checkout", (_req, res) => {
  // No payments are collected in this scaffold. Never accept money for a non-confirmed ticket.
  res.status(501).json({
    error: "Payments are disabled.",
    code: "PAYMENT_INTEGRATION_NOT_CONFIGURED",
    message: "No payment was taken. Payment processing will only be enabled after authorized ticket booking and approved merchant setup."
  });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(frontendDir, "index.html"));
});

app.use((err, _req, res, _next) => {
  console.error("Unhandled server error:", err.message);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(port, () => {
  console.log(`MYRail demo running at http://localhost:${port}`);
  console.log("Live KTMB ticketing and payments are DISABLED until authorized integration.");
});
