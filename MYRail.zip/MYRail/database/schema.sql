-- MYRail initial schema.
-- Run in Supabase SQL editor only when ready. This schema does not enable ticket sales.
create extension if not exists pgcrypto;

create table if not exists public.rail_operators (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  display_name text not null,
  official_url text not null,
  integration_status text not null default 'not_authorized'
    check (integration_status in ('not_authorized','pending','sandbox','authorized','suspended')),
  created_at timestamptz not null default now()
);

create table if not exists public.stations (
  id uuid primary key default gen_random_uuid(),
  operator_id uuid references public.rail_operators(id),
  official_station_code text,
  display_name text not null,
  display_name_ms text,
  data_source text,
  source_verified_at timestamptz,
  active boolean not null default false,
  unique(operator_id, official_station_code)
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  operator_id uuid not null references public.rail_operators(id),
  service_code text,
  display_name text not null,
  service_type text not null,
  active boolean not null default false,
  data_source text,
  source_verified_at timestamptz
);

create table if not exists public.journey_cache (
  id uuid primary key default gen_random_uuid(),
  operator_id uuid not null references public.rail_operators(id),
  provider_journey_id text,
  origin_station_id uuid not null references public.stations(id),
  destination_station_id uuid not null references public.stations(id),
  departure_at timestamptz,
  arrival_at timestamptz,
  fare_minor_units integer,
  currency char(3) not null default 'MYR',
  availability_checked_at timestamptz,
  is_live_verified boolean not null default false,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  operator_id uuid not null references public.rail_operators(id),
  provider_booking_reference text,
  status text not null default 'not_bookable'
    check (status in ('not_bookable','pending','awaiting_payment','confirmed','cancelled','failed','refunded')),
  currency char(3) not null default 'MYR',
  amount_minor_units integer,
  provider_ticket_reference text,
  provider_ticket_issued boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint real_ticket_requires_provider check (
    provider_ticket_issued = false or
    (provider_booking_reference is not null and provider_ticket_reference is not null and status = 'confirmed')
  )
);

create table if not exists public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  provider text not null,
  provider_transaction_id text,
  status text not null default 'not_enabled'
    check (status in ('not_enabled','created','pending','succeeded','failed','refunded','partially_refunded')),
  amount_minor_units integer not null check (amount_minor_units >= 0),
  currency char(3) not null default 'MYR',
  webhook_verified boolean not null default false,
  idempotency_key text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.booking_events (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  event_type text not null,
  source text not null,
  event_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Do not expose these tables to anon/authenticated clients until reviewed policies are added.
-- Enable RLS and write least-privilege policies before any production use.
alter table public.rail_operators enable row level security;
alter table public.stations enable row level security;
alter table public.services enable row level security;
alter table public.journey_cache enable row level security;
alter table public.bookings enable row level security;
alter table public.payment_transactions enable row level security;
alter table public.booking_events enable row level security;

insert into public.rail_operators (code, display_name, official_url)
values ('KTMB', 'Keretapi Tanah Melayu Berhad', 'https://www.ktmb.com.my/')
on conflict (code) do nothing;
